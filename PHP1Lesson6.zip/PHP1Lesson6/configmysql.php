<?
$connection = mysqli_connect("localhost","root","deltadental!","world");