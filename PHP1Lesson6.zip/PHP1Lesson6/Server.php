﻿<?php
$s=strip_tags($_POST['feedback']);
print_r($s);
?>
